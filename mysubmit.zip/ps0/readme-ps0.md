# PS0: Hello SFML

## Contact
Name: Adam Warden

Section:

Time to Complete: 35 minutes


## Description
This project introduces us to SFML libraries by interacting with sprites and shapes on a background. 

### Features
Features of my project include a background, a green circle, and an image of Cristiano Ronaldo. I made the background window larger to fit both shapes. I made the image of Ronaldo movable with arrow keys (up, down, left, right) and it also rotates clockwise (q) and counter clockwise (e).

### Issues
Although I was able to make the image of Ronaldo move and rotate, I was not able to make the green circle bounce across the screen on its own accord, having its boundaries be the border of the window.

### Extra Credit
I added an additional feature that makes the green circle change its color when the mouse is clicked anywhere on the window.


## Integrity
Read the University policy Academic Integrity, and answer the following question:

There are six examples of academic misconduct, labeled (a) through (f). Other than (a), "Seeks to claim credit for the work or efforts of another without authorization or citation," which of these do you think would most apply to this class, and why? Write approx. 100-200 words. Note: there is no single correct answer to this. I am looking for your opinion.

I think that "Seeks to gain an unfair advantage over others by misrepresenting the work, producing work that is not one's own, or unfairly inhibiting or impeding the efforts of others." I think that this would most apply to this class because we are all given the same amount of time to complete the assignments, and we are all given the same resources to complete the assignments. If someone were to copy someone else's code, they would have an unfair advantage over others that have to use that time to figure things out on their own. This would also be unfair to the person whose code was copied because they put in the time and effort to figure out the code on their own.


## Acknowledgements
List all sources of help including the instructor or TAs, classmates, and web pages.

I only used the documentation given to us in class to complete this assignment.

### Credits
List where you got any images or other resources.
https://imgs.search.brave.com/bOsFqL4d0pb3mdboHip02LvUU2ykqcPtmJz0-WLG1j4/rs:fit:860:0:0/g:ce/aHR0cHM6Ly9tZWRp/YS5nZXR0eWltYWdl/cy5jb20vaWQvMTE0/OTE1MDk2OS9waG90/by9jcmlzdGlhbm8t/cm9uYWxkby1mb3J3/YXJkLW9mLXBvcnR1/Z2FsLWNlbGVicmF0/ZXMtdGhlLXZpY3Rv/cnktb2YtdGhlLXRy/b3BoeS11ZWZhLW5h/dGlvbnMuanBnP3M9/NjEyeDYxMiZ3PTAm/az0yMCZjPW5kcU9K/Q1QzeUU3NUMyMlJH/MDFPa1psMElqazRu/QUFzVVBrY3l4MHpB/U0k9